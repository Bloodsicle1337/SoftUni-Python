message = input()

command = input()

while command != "Reveal":
    parts = command.split(":|:")
    action = parts[0]

    if action == "InsertSpace":
        index = int(parts[1])
        message = message[:index] + " " + message[index:]

    elif action == "Reverse":
        substring = parts[1]

        if substring in message:
            message = message.replace(substring, "", 1)
            message += substring[::-1]
        else:
            print("error")
            command = input()
            continue

    elif action == "ChangeAll":
        substring, replacement = parts[1], parts[2]
        message = message.replace(substring, replacement)

    print(message)
    command = input()

print(f"You have a new text message: {message}")