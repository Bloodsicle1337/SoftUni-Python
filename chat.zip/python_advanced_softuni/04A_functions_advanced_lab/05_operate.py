from functools import reduce


def sum_nums(*args):
    return sum(args)

def sub_nums(*args):
    return reduce(lambda x, y: x - y, args)

def mul_nums(*args):
    return reduce(lambda x, y: x * y, args)

def div_nums(*args):
    return reduce(lambda x, y: x / y, args)

operators = {
    "+": sum_nums,
    "-": sub_nums,
    "*": mul_nums,
    "/": div_nums
}

def operate(sign, *args):
    func = operators[sign]
    return func(*args)

print(operate("+", 1, 2, 3))
print(operate("*", 3, 4))