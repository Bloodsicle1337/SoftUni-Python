import os

absolute_path = os.path.abspath(__file__)
path_to_dir = os.path.dirname(absolute_path)

print(absolute_path)

print(path_to_dir)